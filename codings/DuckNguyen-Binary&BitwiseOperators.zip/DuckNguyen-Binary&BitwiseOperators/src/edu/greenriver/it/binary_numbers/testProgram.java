package edu.greenriver.it.binary_numbers;

/**
 * testPogram contains the function calls
 * @author: Duck Nguyen 
 * @date:	02/04/17
 * @testProgram.java
 */

public class testProgram 
{

	public static void main(String[] args) 
	{
		lazyPrint(1);
		BitFunction tester = new BitFunction();
		System.out.println(tester.isSet(3, 0));
		System.out.println(tester.isSet(64, 6));
		System.out.println(tester.isSet(64, 2));
		
		lazyPrint(2);
		tester.wordMask("vertical", 0b11000011);
		tester.wordMask("vertical", 0b10001011);
		
		lazyPrint(3);
		
		BitArray x = tester.locker();
		for(int i = 0; i < 30; i++)
		{
			System.out.println((i+1) + ": " + x.getBit(i));
		}
	}
	
	public static void lazyPrint(int n)
	{
		System.out.println();
		System.out.println("PART " + n +":");
		System.out.println("*************************************");
	}
}
