package edu.greenriver.it.binary_numbers;

public class TestBitArray
{
	public static void main(String[] args)
	{
		BitArray bitArray = new BitArray();

		bitArray.setBit(0, true);
		
		bitArray.setBit(3, false);
		
		System.out.println(bitArray.getData());
		
		for (int i = 0; i < 32; i++)
		{
			System.out.println(bitArray.getBit(i));
		}
	}
}
