package edu.greenriver.it.binary_numbers;

/**
 * BitFunction class contains the three methods as required in the assignment description
 * @author: Duck Nguyen 
 * @date:	02/04/17
 * @Bitfunction.java
 */


public class BitFunction  
{
	// isSet returns true if binary digit at the given index is "set"
	// isSet shift the current digit to LSB position, where it can be accessed easily
	// LSB determines odd (1) or even(0) -> using %2 to find odd/even or if the bit is "set"
	public boolean isSet(int num, int index)
	{
		return ((num >> index)%2 != 0);
	}
	
	// wordMask accepts a string, and mask (assuming same length with word),
	// it then prints out the letter if the ith binary digit of the input mask is "set"
	// for loop is printing backward because of isSet 
	// using charAt to access each character, if it is set according to mask, print it out.
	public void wordMask(String word, int mask)
	{
		for(int i = word.length(); i >= 0; i--)
		{
			if(isSet(mask,i))
			{
				System.out.print(word.charAt(word.length()-i-1));
			}
		}
		System.out.println();
	}
	
	// locker contains a BitArray array lockers
	// nested for loop with the outter loop being 30 students
	// inner for loop being the the 30 lockers
	
	public BitArray locker()
	{
		BitArray lockers = new BitArray();
		
		// students loop
		for (int i = 0; i < 30; i++)
		{
			for(int x = i; x < 30; x+=(i+1))
			{
				boolean temp = !lockers.getBit(x); 
				lockers.setBit(x, temp);
			}
		}

		return lockers;
	}
}// end class