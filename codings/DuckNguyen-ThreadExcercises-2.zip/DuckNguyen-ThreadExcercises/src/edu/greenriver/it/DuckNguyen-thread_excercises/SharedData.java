package edu.greenriver.it.thread_excercises;

import java.util.ArrayList;
import java.util.Collections;

/**
 * @author: Duck Nguyen 
 * @date:	02/18/17
 * @SharedData.java
 * @SharedData prints out the name of all files in "lists" directory
 */ 

public class SharedData
{
	// Object lock to monitor the threads coming in SharedData
	private static Object lock = new Object();
	private static ArrayList<String> arr = new ArrayList<String>();
	
	public static void add(String word)
	{
		synchronized (lock)
		{
			arr.add(word); 	
		}
	}
	
	public static int wordPhraseTotal()
	{
		return arr.size();
	}
	
	public static String getWordPhrase(int position)
	{
		return arr.get(position);
	}
	
	// sort the array for better reading
	public static void sortNow()
	{
		Collections.sort(arr);
	}
	
}// end class
