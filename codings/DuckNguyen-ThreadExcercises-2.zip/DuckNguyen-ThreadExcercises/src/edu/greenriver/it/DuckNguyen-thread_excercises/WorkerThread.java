package edu.greenriver.it.thread_excercises;

import java.io.File;
import java.util.Scanner;

/**
 * @author: Duck Nguyen 
 * @date:	02/18/17
 * @WorkerThread.java
 * @WorkerThread accepts a filename (word list) and opens the given file and adds each line of the file to the shared data class 
 */ 

public class WorkerThread extends Thread
{
	private File f;          
	private String fileName;
	private String word;
	
	public WorkerThread(String fileName)
	{
		this.fileName = fileName;
	}
	
	@Override  
	public void run()
	{
		try 
		{	
			f = new File("list/" + fileName);
			Scanner reader = new Scanner(f);
			while(reader.hasNextLine())
			{
				word = reader.nextLine();
				SharedData.add(word);
			}
			SharedData.sortNow();
			reader.close();
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}	
	}
	
}// end class
