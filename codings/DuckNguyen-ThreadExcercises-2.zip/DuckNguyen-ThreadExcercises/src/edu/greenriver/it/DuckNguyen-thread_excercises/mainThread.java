package edu.greenriver.it.thread_excercises;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner; 

public class mainThread {
	
	// number of files
	public static final int FILES_NUM = 10;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		lazyPrint("Secondary thread that prints out name of all files");
		first();
		
		lazyPrint("Thread that print out total number of lines");
		second("list_1.txt");
		
		lazyPrint("Print number of lines on each file using multiple threads");
		third();
		
		lazyPrint("Search file for keyword");
		fourth();
		
		lazyPrint("Copy words from all file and write it onto master_list");
		fifth();
	}
	
	// lazy print helps readability
	public static void lazyPrint(String a)
	{
		System.out.println();
		System.out.println("**********************************************************");
		System.out.println("Description:" + a);
		System.out.println("**********************************************************");
		System.out.println();
	}
	
	
	// question 1
	public static void first()
	{
		System.out.println("Analyzing lists directory...");
		PrintThread filePrinter = new PrintThread(); 
		filePrinter.start(); 
		try
		{
			filePrinter.join();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Done analyzing lists directory...");
	}
	
	
	//question 2a
	//I separate this method so that it can fit the use of problem 4
	public static void second(String listName)
	{
		CountListThread countLine = new CountListThread(listName);
		countLine.start();
		try
		{
			countLine.join();
			System.out.println("Number of lines in " + countLine.getLineCount());
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}
	
	//question 2b and 2c
	public static void third()
	{
		CountListThread[] threadz = new CountListThread[FILES_NUM];

		/* Question 2b
		try
		{
			String[] fileNames = new File("list").list();
			for(int i = 0; i < threadz.length; i++)
			{
				threadz[i] = new CountListThread(fileNames[i]);
				threadz[i].start();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		*/
		
		
		// Question 2c
		try
		{
			String[] fileNames = new File("list").list();
			for(int i = 0; i < threadz.length; i++)
			{
				threadz[i] = new CountListThread(fileNames[i]);
				threadz[i].start();
				threadz[i].join();
				System.out.println(threadz[i].getLineCount());
			}
		}catch(Exception e){
			e.printStackTrace();
		}		
	}
	
	// question 3a and 3b
	public static void fourth()
	{
		/* Question 3a
		System.out.println();
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the term to search for: ");
		String term = input.next();
		input.close();
		SearchThread search = new SearchThread(term);
		search.start();
		*/
		
		
		SearchThread[] threadz = new SearchThread[FILES_NUM];
		
		try
		{

			Scanner input = new Scanner(System.in);
			System.out.println("Enter the term to search for: ");
			String term = input.nextLine();
			input.close();
			//System.out.println(term);
			
			String[] fileNames = new File("list").list();
			for(int i = 0; i < threadz.length; i++)
			{
				threadz[i] = new SearchThread(term, fileNames[i]);
				threadz[i].start();
				threadz[i].join();
			}
		}catch(Exception e){
			e.printStackTrace();
		}		
		
	}
	
	// question 4a + 4b
	public static void fifth()
	{	
		// first loop to copy all the words from different files and copy them onto internal array
		WorkerThread[] threadz = new WorkerThread[FILES_NUM];
	
		try
		{
			String[] fileNames = new File("list").list();
			for(int i = 0; i < threadz.length; i++)
			{
				threadz[i] = new WorkerThread(fileNames[i]);
				threadz[i].start();
				threadz[i].join();
			}
			//System.out.println(SharedData.wordPhraseTotal());
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		// second loop to write all the words from internal array to the master_list file
		try
		{
			PrintWriter printWriter = new PrintWriter("list/master_list.txt");
			for(int i = 0; i < SharedData.wordPhraseTotal(); i++)
			{
				printWriter.println(SharedData.getWordPhrase(i));
			}
			printWriter.close();
		} catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		second("master_list.txt");
	}

}//end main