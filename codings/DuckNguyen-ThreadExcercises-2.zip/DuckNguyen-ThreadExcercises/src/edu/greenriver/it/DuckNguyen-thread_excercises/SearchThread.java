package edu.greenriver.it.thread_excercises;

import java.io.File;
import java.util.Scanner;

/**
 * @author: Duck Nguyen 
 * @date:	02/18/17
 * @SearchThread.java
 * @SearchThread stores a file name (word list) and a search term (string) as a field
 */

public class SearchThread extends Thread{
	private File f;
	private String fileName; 
	private String name;
	private String term;
	private boolean found;
	
	// first constructor for problem 3a
	public SearchThread(String term)
	{
		this.term = term; 
		term.toLowerCase();
	}
	
	// second constructor for problem 3b
	// SearchThread acceps a search term, as well as file Name
	public SearchThread(String term, String name)
	{
		this.term = term;
		term.toLowerCase();
		this.name = name;
	}
	
	
	// run() method
	// codes commented out are for 3a
	// search in file for matching keywords 	
	@Override
	public void run()
	{
		found = false;
		// fileName = "list_1.txt";

		try 
		{	
			// f = new File("list/" + fileName);
			f = new File("list/" + name);
			Scanner reader = new Scanner(f);
			while(reader.hasNextLine() && !found)
			{
				if(term.equals(reader.nextLine()))
				{
					found = true;
					// System.out.println("\"" + term + "\"" + " found in word-phrase lists/" + fileName);
					System.out.println("\"" + term + "\"" + " found in word-phrase lists/" + name);
				}
			}
			
			if (!found)
			{
				//System.out.println("Does not exist the term you're searching for");
				System.out.println("File " + name + " does not contain the word you're looking for");
	
			}
			reader.close();
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}	
		
	}	
}// end class
