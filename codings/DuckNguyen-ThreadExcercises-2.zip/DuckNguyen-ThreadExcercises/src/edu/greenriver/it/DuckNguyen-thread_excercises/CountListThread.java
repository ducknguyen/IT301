package edu.greenriver.it.thread_excercises;

import java.util.Scanner;
import java.io.File;

public class CountListThread extends Thread{
	private String listName;
	private File f;
	private int lineNo = 0;
	private String lineCount;
	
	public CountListThread(String listName)
	{
		this.listName = listName;
	}
	
	@Override
	public void run()
	{
		try 
		{	
			f = new File("list/" + listName);
			
			Scanner reader = new Scanner(f);
			while(reader.hasNextLine())
			{
				lineNo++;
				reader.nextLine();
			}
			lineCount = listName + ": " + lineNo;
			//System.out.println(listName + ": " + lineNo);
			reader.close();
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
		
	}
	
	public String getLineCount()
	{
		return lineCount;
	}
	
}
