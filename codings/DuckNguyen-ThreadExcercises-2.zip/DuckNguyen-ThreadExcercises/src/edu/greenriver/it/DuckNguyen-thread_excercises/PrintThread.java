package edu.greenriver.it.thread_excercises;

import java.io.File;

/**
 * @author: Duck Nguyen 
 * @date:	02/18/17
 * @PrintThread.java
 * @PrintThread prints out the name of all files in "lists" directory
 */ 

public class PrintThread extends Thread {
	private File f;
	private String[] paths;
	
	// run() method
	// search in directory for list of file names stored in paths
	// for each path in paths, print them out
	@Override
	public void run()
	{
		try
		{
			f = new File("list");

			paths = f.list(); 
			
			for(String path:paths)
			{
				System.out.println("Found file: " + path);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}//end class
