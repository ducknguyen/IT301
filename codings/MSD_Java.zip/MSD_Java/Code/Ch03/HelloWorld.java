/**
 * A Hello World Program in Java
 */

public class HelloWorld {

    /**
     * The entry point for this class.  When executed the
     * program will simply print "Hello World" and terminate.
     *
     * @param args command line arguments.
     */

    public static void main( String args[] ) {
	System.out.println( "Hello World" );
    }

} // HelloWorld
