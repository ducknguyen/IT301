class Supermost {

    private int id;

    public Supermost( int myId ) {
	id = myId;
    }

}

public class Subclass extends Superclass {

    public static void main( String args[] ) {
	Subclass x = new Subclass();
    }
}
