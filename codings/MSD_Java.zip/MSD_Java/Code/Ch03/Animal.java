public interface Animal {

    public String speak();

    public boolean isCarnivore();
}
