public class main {

  public static void main(String argv[]) {
    new Calculator("JavaCalc");
  }
}
