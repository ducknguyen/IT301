import javax.swing.JFrame;

public class FrameDemo {

    public static void main( String args[] ) {
	JFrame win = new JFrame( "A JFrame" );
	win.setVisible( true );
    }

} // FrameDemo
