package edu.greenriver.it.data_algorithm;

/**
 * @author: Duck Nguyen 
 * @date:	03/19/17
 * @Interval1D.java
 * @Interval1D checks if if two intervals intersect each other
 */

public class Interval1D
{
	private double lo;
	private double hi;
		
		// constructor takes pair of doubles
		public Interval1D(double lo, double hi)
		{
			this.lo = lo;
			this.hi = hi;
		}
		/**
		 * 
		 * @param that
		 * @return false if max of one interval is less than min of the other
		 */
		public boolean intersects(Interval1D that)
		{
			if (this.hi < that.lo)
			{
				return false;
			}
			else if (that.hi < this.lo)
			{
				return false;
			}
			return true;
		}
		
		// simple toString to check outputs
		@Override
		public String toString()
		{
			return "[" + lo + ", " + hi + "]";
		}
}// end class