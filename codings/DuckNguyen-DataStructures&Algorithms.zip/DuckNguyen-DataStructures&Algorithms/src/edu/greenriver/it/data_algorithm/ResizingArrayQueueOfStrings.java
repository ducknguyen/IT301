package edu.greenriver.it.data_algorithm;

import java.util.Arrays;
import java.util.NoSuchElementException;

/**
 * @author: Duck Nguyen 
 * @date:	03/19/17
 * @ResizingArrayQueueOfStrings.java
 * ResizingArrayQueueOfStrings stores an internal fixed-size array that resizes itself automatically when there's no more space
 */

public class ResizingArrayQueueOfStrings
{
	/**
	 * arr	- internal 
	 * num	- number of elements in the array
	 * first- first element in queue
	 * last - next available index
	 */
	private String[] arr;
	private int num = 0;
	private int first;
	private int last; 
	
	// constructor initialize a String array of size 10
	public ResizingArrayQueueOfStrings()
	{
		arr = new String[10];
	}
	
	// adds an element to queue
	public void enqueue(String element)
	{
		// if number of elements == internal array length -> resize by doubling it
		if (num == arr.length)
		{
			resize(2 * arr.length);
		}
		
		arr[last++] = element;
		
		// reset pointer of last
		if (last == arr.length)
		{
			last = 0; 
		}
		num++;
	}
	// remove the element in front of queue
	public String dequeue()
	{
		// check if queue is empty or not, if yes, throw exception
		if (isEmpty())
		{
			throw new NoSuchElementException("Queue is currently empty"); 
		}
		
		String element = arr[first];
		arr[first] = null;
		num--;
		first++;
		
		// reset pointer of first element
		if (first == arr.length)
		{
			first = 0; 
		}
		return element;
	}
	
	// return size of queue 
	public int size()
	{
		return last;
	}
	
	/**
	 * create temp array to store elements from initial fixed-size array
	 * arr is then == temp
	 * set first to 0
	 * last = number of elements in queue
	*/
	private void resize (int length)
	{
		String[] temp = Arrays.copyOf(arr, length);
		arr = temp;
		first = 0;
		last = num;
	}
	
	// check if queue is empty
	public boolean isEmpty()
	{
		return num == 0;
	}
	
	@Override
	// simple toString method to check outputs
	public String toString()
	{
		return Arrays.toString(arr);
	}
}// end class
