package edu.greenriver.it.data_algorithm;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

/**
 * @author: Duck Nguyen 
 * @date:	03/19/17
 * @Driver.java
 * @Driver displays each coding sample's section and its requirements
 */
public class Driver
{
	
	public static void main(String[] args)
	{
		// scanner object
		Scanner read = new Scanner(System.in);
		
		/**
		 * SECTION 1.2.2 - Interval1D
		 */
		lazyPrint("1.2.2", "Interval1D that takes an int value N input, reads N intervals and prints all pairs that intersect.");		
		
		System.out.println("For simplicity, please enter an even number (int):");
		int N = read.nextInt();
		Interval1D[] intervals = new Interval1D[N];
		
		for (int i = 1; i <= N; i++)
		{
			System.out.println("Interval #" + i + ": please enter first double value");
			double first = read.nextDouble();
			System.out.println("Interval #" + i + ": please enter second double value");
			double second = read.nextDouble();
			intervals[i-1] = new Interval1D(first, second);
		}
		
		for (int i = 0; i < intervals.length; i+=2)
		{
			if (intervals[i].intersects(intervals[i+1]))
			{
				System.out.println(intervals[i] + " intersects " + intervals[i+1]);
			}
			else
			{
				System.out.println(intervals[i] + " does not intersect " + intervals[i+1]);
			}
		}
		// avoid the scanner from dangling in the line
		read.nextLine();
		
		// Interval1D interval1 = new Interval1D(18.0, 42.0);
		// Interval1D interval2 = new Interval1D(35.0, 70.0);
		// System.out.println(interval1.intersects(interval2));
		/**
		 * SECTION 1.2.6 - Circular Shifts
		 */
		lazyPrint("1.2.6", "isCircularRotation checks whether two strings are circular shifts of one another.\nSample code is in driver class.");
		
		System.out.println("Enter first String:");
		String first = read.nextLine();
		System.out.println("Enter second String:");
		String second = read.nextLine();
		System.out.println(isCircularRotation(first, second));
		
		// System.out.println(isCircularRotation("ACTGACG", "TGACGAC"));
		// System.out.println(isCircularRotation("racecar", "carrace"));
		// System.out.println(isCircularRotation("duck", "quack"));
		
		/**
		 * SECTION 1.3.4 - Parentheses
		 */
		lazyPrint("1.3.4", "Parentheses reads a text stream and determine whether its parentheses are properly balanced using stack");
		
		Parentheses check = new Parentheses();
		System.out.println("Enter a series of parentheses to see if they're balanced:");
		String parentheses = read.nextLine();
		System.out.println(check.isBalance(parentheses));
		
		// System.out.println(check.isBalance("[()]{}{[()()]()}"));
		// System.out.println(check.isBalance("[({})]"));
		// System.out.println(check.isBalance("[(])"));
		// System.out.println(check.isBalance("(()[["));
		
		lazyPrint("1.3.14", "ResizingArrayQueueOfStrings implments queue abstraction, and modified to resize by itself");
		ResizingArrayQueueOfStrings resizeQueue = new ResizingArrayQueueOfStrings();
		for (int i = 0;i <= 21; i++)
		{
			String num = Integer.toString(i);
			resizeQueue.enqueue(num);
		}	
		System.out.println(resizeQueue.size());
		// System.out.println(resizeQueue);
		
		while (!resizeQueue.isEmpty())
		{
			System.out.print(resizeQueue.dequeue()+ " ");
		}
		System.out.println();
		
		// check to see queue will throw exception if there's no item on queue to remove
		// queue.dequeue();
		
		/**
		 * SECTION 1.3.27 - max()
		 */
		lazyPrint("1.3.27", "max() suppose to take a reference to the first node in a linked list and returns the value of "
				+ "the maximum key in the list. Mine is kinda hacky, Sample code is in driver class.");
		LinkedList<Integer> list = new LinkedList<Integer>();
		Random r = new Random();
		for (int i = 0; i <= 25; i++)
		{
			int num = r.nextInt(100) +1;
			list.add(num);
		}
		System.out.println(list);
		System.out.println("SIZE: " + list.size());
		System.out.println(max(list));
		
		// close scanner
		read.close();
	}
	
	
	// 1.2.6 code sample
	public static boolean isCircularRotation(String s, String t)
	{
		// check if the two strings have the same length
		if (s.length() != t.length())
		{
			return false;
		}
		
		// check if s is a part of t concatenated with s
		if (s.concat(s).indexOf(t) != 0)
		{
			return true;
		}
		return false;
	}
	
	// 1.3.2 code sample
	public static int max (LinkedList<Integer>list)
	{
		Integer maxNum = 0;
		
		// return 0 if list is empty
		if (list.isEmpty())
		{
			return maxNum;
		}	
		// else return the max integer in the list
		maxNum = Collections.max(list);
		return maxNum;
	}
	
	// lazyPrint for code readability
	public static void lazyPrint(String name, String description)
	{
		System.out.println();
		System.out.println("---------------------------------------------------------------------------------------------------------------");
		System.out.println("* Section " + name + " code sample *");
		System.out.println("* " + description);
		System.out.println("---------------------------------------------------------------------------------------------------------------");
	}
}// end main