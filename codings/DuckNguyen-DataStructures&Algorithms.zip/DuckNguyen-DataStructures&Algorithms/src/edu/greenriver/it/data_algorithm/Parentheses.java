package edu.greenriver.it.data_algorithm;

import java.util.Stack;

/**
 * @author: Duck Nguyen 
 * @date:	03/19/17
 * @Parentheses.java
 * Parentheses check if a sets of parentheses are balanced or not using a stack
 */

public class Parentheses
{
	private Stack<Character> chars;
	
	// constructor initialize a stack of chars
	public Parentheses()
	{
		chars = new Stack<Character>();
	}
	
	// isBalance to check input Parentheses set
	public boolean isBalance (String input)
	{
		if (input.isEmpty()) return true;
		
		/**
		 * loop through each char in input
		 * if currentChar are open ones - (, {, [ -> push to stack
		 * if currentChar are close ones - ), }, ] -> compare it to the one before it in the stack
		 * if match -> pop(); else push()
		 * if balance, stack ends up empty since every char is matched (popped to MadMax).
		 */
		for(int i = 0; i < input.length(); i++)
		{
			char currentChar = input.charAt(i);
			if (currentChar == '(' || currentChar == '{' || currentChar =='[')
			{
				chars.push(currentChar);
			}
			
			if (currentChar == ')' || currentChar == '}' || currentChar ==']')
			{
				char lastChar = chars.peek();
				if (!chars.isEmpty())
				{
					if (currentChar == ')' && lastChar =='(')
					{
						chars.pop();
					}
					
					else if (currentChar == '}' && lastChar =='{')
					{
						chars.pop();
					}
					
					else if (currentChar == ']' && lastChar =='[')
					{
						chars.pop();
					}
				}	
				else
				{
					return false;
				}
				
			}
		}
		return chars.isEmpty();
	}
}// end class