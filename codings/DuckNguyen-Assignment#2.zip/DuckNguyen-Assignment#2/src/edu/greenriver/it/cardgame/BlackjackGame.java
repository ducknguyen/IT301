package edu.greenriver.it.cardgame;

import java.util.*;

import edu.greenriver.it.cards.Card;
import edu.greenriver.it.console.Console;

/**
 *BlackjackGame simulates a game of BlackJack
 * @author: Duck Nguyen 
 * @date:	01/20/17
 * @BlackJackGame.java
 */

public class BlackjackGame extends CardGame
{
	// private fields 
	private int playerTotal;
	private int dealerTotal;
	private static final int SHUFFLES = 520; 
	private static final int MAXNUM = 21;
	
	// create card deck, player's hand to store cards,
	List<Card> deck;
	List<Card> hand;
	List<Card> dealerHand;
	
	/**
	 * pass "blackjack" to its parent
	 * create the deck that holds 52 cards for the game
	 * print the welcomeMessage
	 */
	public BlackjackGame(String name)
	{
		super("BlackJack");
		this.deck = new ArrayList<Card>();
		
		for(int i = Card.SPADES; i <= Card.HEARTS; i++)
		{
			for(int j = Card.ACE; j <= Card.KING; j++)
			{
				Card temp = new Card(i,j);
				deck.add(temp);
			}
		}
		
		Console.print(this.welcomeMessage);
	}
	
	/**
	 * shuffle using the constant 
	 * shuffle by randomly picking two indexes and switch them
	 */
	@Override
	public void shuffle()
	{
		Random r = new Random();
		for(int i = 0; i < SHUFFLES; i++)
		{
			int a = r.nextInt(deck.size()); 
			int b = r.nextInt(deck.size());
			Card temp = deck.get(a);
			deck.set(a, deck.get(b));
			deck.set(b, temp);
			//System.out.println(deck);
		}
		//System.out.println(deck);
	}
	
	/**
	 * deal a single card to player
	 * copy one card from the deck, then removes the original card in deck
	 * return the temp card
	 */
	@Override
	public Card deal()
	{
		Card temp = deck.get(0);
		deck.remove(0);
		Console.print("You are dealt a(n) " + temp.toString());
		return temp;
	}

	/**
	 * deal a single card to dealer
	 * copy one card from the deck, then removes the original card in deck
	 * return the temp card
	 */
	public Card dealerDeal()
	{
		Card temp = deck.get(0);
		deck.remove(0);
		Console.print("The dealer is dealt a(n) " + temp.toString());
		return temp;
	}
	
	
	/**
	 * play a round of BlackJack with player
	 * total on hand is reset to zero every round
	 * deck is then shuffle and cards are added to hand
	 */
	@Override
	public void playRound()
	{
		playerTotal = dealerTotal = 0;
		shuffle();
		hand = new ArrayList<Card>(); 
		hand.add(deal());
		hand.add(deal());
		for (Card c: hand)
		{
			playerTotal += c.getValue();
		}
		Console.print("Total: " + playerTotal);
		
		boolean cont = true;
		
		while (cont)
		{
			boolean hit = Console.getBoolean("Hit? (True/False)");
			
			// hitting - deal one card add to hand, playerTotal += value
			if (hit) 
			{
				hand.add(deal());
				playerTotal = 0;
				for (Card c : hand)
				{
					playerTotal += c.getValue();
				}
				
				Console.print("Total: " + playerTotal);

				if (playerTotal > MAXNUM)
				{
					cont = false;
				}
			}
			else
			{
				cont = false;
			}
		}
		// winning, losing, and tie condition
		if (playerTotal > MAXNUM)
		{
			Console.print("Player Bust!");
		}
		else
		{			
			if (dealerRound())
				{
				if (dealerTotal > playerTotal)
				{
					Console.print("Dealer Wins!");
				}
				else 
				{
					Console.print("Match is a tie!");
				}
			}
			else
			{
				Console.print("Dealer Loses!");
			}
		}
		deck.addAll(hand);
		hand.clear();
	}
	
	/**
	 * dealer turn to play BlackJack
	 * total on hand is reset to zero every round
	 * deck is then shuffle and cards are added to hand
	 */
	public boolean dealerRound()
	{
		dealerHand = new ArrayList<Card>(); 
		dealerHand.add(dealerDeal());
		dealerHand.add(dealerDeal());
		for (Card c: dealerHand)
		{
			dealerTotal += c.getValue();
		}
		Console.print("Total: " + dealerTotal);
		
		boolean cont = true;
		
		while (cont)
		{
			if ((dealerTotal <= playerTotal && dealerTotal != MAXNUM) && 
					!(dealerTotal == playerTotal && dealerTotal > 16)) 
			{
				dealerHand.add(dealerDeal());
				dealerTotal = 0;
				for (Card c : dealerHand)
				{
					dealerTotal += c.getValue();
				}
				
				Console.print("Total: " + dealerTotal);
				
				if (dealerTotal > MAXNUM)
				{
					cont = false;
				}
			}
			else
			{
				cont = false;
			}
		}
		
		deck.addAll(dealerHand);
		dealerHand.clear();
		
		if (dealerTotal > MAXNUM)
		{
			Console.print("Dealer Bust!");
			return false;
		}
		return true;
	}
}// end class
