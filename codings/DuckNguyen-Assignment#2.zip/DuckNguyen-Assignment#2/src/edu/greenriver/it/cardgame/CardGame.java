package edu.greenriver.it.cardgame;

import edu.greenriver.it.cards.Card;

/**
 *CardGame hold a game name and welcome message for different types of card games
 * @author: Duck Nguyen 
 * @date:	01/20/17
 * @CardGame.java
 */
public abstract class CardGame
{
	protected String gameName;
	protected String welcomeMessage; 
	
	// constructor
	public CardGame(String name) // 1 param, as per spec.
	{
		this.gameName = name;
		welcomeMessage = "Play a BlackJack Game!\n"
				+ "Welcome to my " + name + " Game!";
	}
	
	// abstract methods
	public abstract void shuffle();

	public abstract Card deal();

	public abstract void playRound();
}// end class
