package edu.greenriver.it.gametest;

import edu.greenriver.it.cardgame.BlackjackGame;
import edu.greenriver.it.console.Console;

/**
 * CardGameTest facilitates the text-base BlackJack game
 * @author: Duck Nguyen 
 * @date:	01/20/17
 * @CardGameTest.java
 */
public class CardGameTest 
{
	public static void main(String[] args){
		/**
		 * create a game of blackjack.
		 * prompt user to play one single round
		 * then loop for rounds (fence-post problem)
		 */
		BlackjackGame x = new BlackjackGame("BlackJack");
		x.playRound();
		while(Console.getBoolean("Play another (True/False)"))
		{
			x.playRound();
		}
	}
}//end class
