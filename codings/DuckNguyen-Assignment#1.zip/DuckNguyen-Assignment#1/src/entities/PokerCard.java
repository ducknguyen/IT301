/**
 * 
 */
package entities;

/**
 * @author: Duck Nguyen 
 * @date:	01/12/17
 * @PokerCard.java
 */
public class PokerCard extends PlayingCard{
	// constants
	public final static int SPADES = 0,
			CLUBS = 1,
			DIAMONDS = 2,
			HEARTS = 3;
	public final static int ACE = 1,
			JACK = 11,
			QUEEN = 12,
			KING = 13;
	
	// private fields 
	private int suit;
	private int rank;
	private static final String[] suits={"Spades", "Clubs", "Diamonds", "Hearts"};
	private static final String[] ranks={
			"Ace",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9",
			"10",
			"Jack",
			"Queen",
			"King"
	};
	
	// constructor
	public PokerCard(int suit, int rank) {
		super("red", "2.5 inches", "4 inches");
		if (suit == SPADES || suit == CLUBS) {
			this.setColor("black");
		}
		this.suit = suit;
		this.rank = rank; 
		// TODO Auto-generated constructor stub
	}
	
	//setters and getters
	/**
	 * @return the suit
	 */
	public int getSuit() {
		return suit;
	}

	/**
	 * @param suit the suit to set
	 */
	public void setSuit(int suit) {
		this.suit = suit;
	}

	/**
	 * @return the rank
	 */
	public int getRank() {
		return rank;
	}

	/**
	 * @param rank the rank to set
	 */
	public void setRank(int rank) {
		this.rank = rank;
	}
	
	// toString 
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[" + ranks[rank-1] + " of " + suits[suit] + "]";
	}
	
}//end class 
