package entities;

/**
 * @author: Duck Nguyen 
 * @date:	01/12/17
 * @PlayingCard.java
 */
public class PlayingCard {
	
	// private fields
	private String color;
	protected String width;
	protected String height;
	
	// constructor
	public PlayingCard(String color, String width, String height){
		this.color = color;
		this.width = width;
		this.height = height; 
	}
	
	// setters and getters 
	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the width
	 */
	public String getWidth() {
		return width;
	}

	/**
	 * @param width the width to set
	 */
	public void setWidth(String width) {
		this.width = width;
	}

	/**
	 * @return the height
	 */
	public String getHeight() {
		return height;
	}

	/**
	 * @param height the height to set
	 */
	public void setHeight(String height) {
		this.height = height;
	}
	
	// toString method 
	/**
	 * @param toString
	 */
	public String toString(){
		return "PlayingCard [color=" + this.color + ", width=" + this.width + ", height= " + this.height + "]"; 
	}
	
	
	
}//end class
