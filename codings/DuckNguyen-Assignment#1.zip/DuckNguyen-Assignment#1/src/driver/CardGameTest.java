package driver;
import java.util.*;
import entities.*;

/**
 * @author: Duck Nguyen 
 * @date:	01/12/17
 * @PokerCard.java
 */
public class CardGameTest {
	// constants for shuffling
	private static final int SHUFFLES = 520;
	
	public static void main(String[] args){
		// TODO Auto-generated method stub
		// creating deck and add card to it
		List<PokerCard> deck = new ArrayList<PokerCard>();
		for(int i = PokerCard.SPADES; i <= PokerCard.HEARTS; i++){
			for(int j = PokerCard.ACE; j <= PokerCard.KING; j++){
				PokerCard temp = new PokerCard(i,j);
				deck.add(temp);
			}
		}
		// System.out.print(deck);
		// functions calls
		shuffle(deck);
		nShuffle(deck,5);
		consolePrint(deck);
		
	}
	
	// shuffle method - shuffling using constant SHUFFLES
	// randomly pick an index and switch it with another random index
	public static void shuffle(List<PokerCard> deck){
		Random r = new Random();
		for(int i = 0; i < SHUFFLES; i++){
			int a = r.nextInt(deck.size()); 
			int b = r.nextInt(deck.size());
			PokerCard temp = deck.get(a);
			deck.set(a, deck.get(b));
			deck.set(b, temp);
			//System.out.println(deck);
		}
		//System.out.println(deck);
	}
	
	// nShuffle method - shuffling n time
	// call shuffle - reduce redundancy 
	public static void nShuffle(List<PokerCard> deck, int n){
		for(int i = 0; i < n; i++){
			shuffle(deck);
		}
		//System.out.println(deck);
	}
	
	// consolePrint method - customize printing 
	public static void consolePrint(List<PokerCard> deck){
		for(int i = 0; i < deck.size(); i++){
			System.out.println(deck.get(i));
		}
	}
}//end class
