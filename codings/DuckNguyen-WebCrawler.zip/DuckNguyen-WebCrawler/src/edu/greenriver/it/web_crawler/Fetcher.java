package edu.greenriver.it.web_crawler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * @author: Duck Nguyen 
 * @date:	03/06/17
 * @Fetcher.java
 * @Fetcher accepts a URL, and downloads HTML page
 */

public class Fetcher extends Thread {
	
	private static int fetcherCount;
	private SharedPageQueue pages;
	private SharedLinkQueue links;
	private static int failCount;
	
	public Fetcher(SharedLinkQueue links, SharedPageQueue pages)
	{
		this.pages = pages; 
		this.links = links;
	}
	
	@Override
	public void run()
	{
		while( true )
		{
			fetcherCount++;
			String currentLink;
			try
			{
				currentLink = links.getNextLink();
				
				URL url = new URL(currentLink);
				HttpURLConnection connection = (HttpURLConnection)url.openConnection();
				
				// tracking fail downloads
				if(connection.getResponseCode() != 200)
				{
					failCount ++;
				}
				
				BufferedReader download = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				String pageTexts;
				StringBuilder content = new StringBuilder(); 
				
				// loop over the HTML line by line
				while((pageTexts = download.readLine()) != null) 
				{
					content.append(pageTexts + "\n");
				}
		        download.close();
		        //System.out.println(content.toString());
		        
		        pageTexts = content.toString();
		        //System.out.println(pageTexts);
		        pages.addPage(pageTexts);
     
		        
			} catch (IOException | InterruptedException e) 
			{
				// do nothing
			}
		} //end main loop
	}// end run()
	
	public int failedDownloads()
	{
		return failCount;
	}
	
	public int fetcherNum()
	{
		return fetcherCount;
	}
}// end class
