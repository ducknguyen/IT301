package edu.greenriver.it.web_crawler;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author: Duck Nguyen 
 * @date:	03/06/17
 * @Parser.javaß
 * @Parser accepts HTML, parses links, and keywords
 */

public class Parser extends Thread {
	private static int count;
	private int parserCount;
	private ArrayList<String> keywords;
	private String pageContent;
	private SharedLinkQueue links;
	private SharedPageQueue pages;
	public static final int MAX_SIZE = 50000;
	
	public Parser (SharedLinkQueue links, SharedPageQueue pages)
	{
		this.links = links;
		this.pages = pages;
	}
	
	@Override
	public void run()
	{	
		
		parserCount++;
		while( true )
		{
			try
			{
				pageContent = pages.getNextPage();
				// pattern as suggested by Josh
				Pattern pattern = Pattern.compile("href=\"(http:.*?)\"");
				Matcher matcher = pattern.matcher(pageContent);

				while (matcher.find())
				{
				    String link = matcher.group(1);
				    links.addLink(link);
				}
					
				for (String word : keywords){
					Pattern p = Pattern.compile(word);
					Matcher m = p.matcher(pageContent);
					while (m.find())
					{
						count++;
					}
				}
				
			} 
			
			catch (InterruptedException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	// find occurrences of keyword
	public int countKeys()
	{
		return count;
	}
	
	public int parserNum()
	{
		return parserCount;
	}
	
	public void helper(ArrayList<String> keywords)
	{
		this.keywords = keywords;
	}
}
