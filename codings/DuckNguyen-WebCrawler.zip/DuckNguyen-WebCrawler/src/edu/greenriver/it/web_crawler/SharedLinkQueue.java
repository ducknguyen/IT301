package edu.greenriver.it.web_crawler;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;

/**
 * @author: Duck Nguyen 
 * @date:	03/06/17
 * @SharedLinkQueue.java
 * @SharedLinkQueue stores URLs, tracks seen URLs, and total URLs
 */

public class SharedLinkQueue
{
	private HashSet<String> seen;
	protected static Queue<String> linkQ;
	public static final int MAX_SIZE = 50000; 
	
	public SharedLinkQueue()
	{
		seen = new HashSet<String>();
		linkQ = new LinkedList<String>();
	}
	// only Parser uses this method
	public void addLink(String url) throws InterruptedException
	{
		synchronized(linkQ)
		{
			while( linkQ.size() >= MAX_SIZE )
			{
				linkQ.wait();
			}
			if (!seen.contains(url))
			{
				seen.add(url);
				//System.out.println(seen);
				linkQ.add(url);
				linkQ.notify();
			}
		}		
	}
	
	// only Fetcher uses this method
	public String getNextLink() throws InterruptedException
	{
		synchronized(linkQ)
		{
			if(linkQ.isEmpty())
			{
				linkQ.wait();
			}
			String link = linkQ.poll();
			linkQ.notify();
			return link;
		}
	}
	
	public int getLinksFound()
	{
		synchronized(linkQ)
		{
			return linkQ.size();
		}
	}
	
	// not sure if i need this
	boolean isFull()
	{
		boolean full = true;
		if (linkQ.size() < MAX_SIZE)
		{
			return !full;
		}
		return full; 
	}
}
