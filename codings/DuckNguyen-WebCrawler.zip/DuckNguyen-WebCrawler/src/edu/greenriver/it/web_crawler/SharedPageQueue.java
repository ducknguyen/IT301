package edu.greenriver.it.web_crawler;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @author: Duck Nguyen 
 * @date:	03/06/17
 * @SharedPageQueue.java
 * @SharedPageQueue stores pages, and track total pages downloaded
 */

public class SharedPageQueue {
	private static Queue<String> pageQ;
	public static final int MAX_SIZE = 50000; 
	
	public SharedPageQueue()
	{
		pageQ = new LinkedList<String>();
	}
	
	public void addPage(String pageText) throws InterruptedException
	{
		synchronized(pageQ)
		{
			while(pageQ.size() >= MAX_SIZE)
			{
				pageQ.wait();
			}
			pageQ.add(pageText);
			pageQ.notify();
		}
	}
	
	public String getNextPage() throws InterruptedException
	{
		synchronized(pageQ)
		{
			while (pageQ.isEmpty())
			{
				pageQ.wait();
			}
			String pageContent = pageQ.poll();
			pageQ.notify();
			return pageContent;
		}
	}
	
	public int getPagesDownloaded()
	{
		synchronized(pageQ)
		{
			return pageQ.size();
		}
	}
	
	// not sure if i need this
	boolean isFull()
	{
		boolean full = true;
		if (pageQ.size() < MAX_SIZE)
		{
			return !full;
		}
		return full; 
	}
}