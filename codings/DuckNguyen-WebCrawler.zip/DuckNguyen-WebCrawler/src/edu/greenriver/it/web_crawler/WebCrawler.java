package edu.greenriver.it.web_crawler;

import java.util.ArrayList;
import java.util.Scanner;
/**
 * @author: Duck Nguyen 
 * @date:	03/06/17
 * @WebCrawler.java
 * @WebCrawler is client side
 */

public class WebCrawler
{

	public static void main(String[] args) throws Exception {
        SharedLinkQueue slq = new SharedLinkQueue();
        SharedPageQueue spq = new SharedPageQueue();
        ArrayList<String> keywords = new ArrayList<String>();
        Parser parser = null;
        Fetcher fetcher = null;
        
        
		while ( true )
		{
			
			System.out.println("1. Add seed URL");
			System.out.println("2. Add consumer");
			System.out.println("3. Add producer");
			System.out.println("4. Add keyword search");
			System.out.println("5. Print stats");
			
			Scanner read = new Scanner(System.in);
			
			int choice = read.nextInt();
			
			if (choice == 1)
			{
				System.out.println("New seed URL>");
				slq.addLink(read.next());
				System.out.println("***********************");
			}
			else if (choice == 2)
			{	
				parser = new Parser(slq, spq);
				parser.helper(keywords);
				System.out.println("Starting new parser...");
				parser.start();
				System.out.println("***********************");
			}
			else if (choice == 3) 
			{
				fetcher = new Fetcher(slq, spq);
				System.out.println("Starting new producer...");
				fetcher.start();
				System.out.println("***********************");
			}
			else if (choice == 4) 
			{
				System.out.println("New keyword>");
				keywords.add(read.next());	
				System.out.println("***********************");
			}
			else
			{
				System.out.println("Keywords found: " + parser.countKeys());
				System.out.println("Links found: " + slq.getLinksFound());
				System.out.println("Pages found: " + spq.getPagesDownloaded());
				System.out.println("Failed downloads: " + fetcher.failedDownloads());
				System.out.println("Producers: " + fetcher.fetcherNum());
				System.out.println("Consumers: " + parser.parserNum());
				System.out.println();
			}
		}
    }
}
